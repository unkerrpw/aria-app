# 📱 Как собрать ARIA APK через Termux + EAS

## Что нужно
- Termux (из F-Droid, НЕ из Play Store — там старая версия)
- Аккаунт на expo.dev (бесплатно)
- Интернет

---

## Шаг 1 — Установка зависимостей в Termux

```bash
# Обновить пакеты
pkg update && pkg upgrade -y

# Установить Node.js и git
pkg install nodejs git -y

# Проверить версии (Node должен быть 18+)
node --version
npm --version
```

---

## Шаг 2 — Установка EAS CLI

```bash
npm install -g eas-cli expo-cli

# Проверка
eas --version
```

> ⚠️ Если ошибка `EACCES` — выполни:
> ```bash
> mkdir -p ~/.npm-global
> npm config set prefix ~/.npm-global
> echo 'export PATH=~/.npm-global/bin:$PATH' >> ~/.bashrc
> source ~/.bashrc
> ```

---

## Шаг 3 — Подготовка проекта

```bash
# Скопируй папку aria-v6 в Termux (например через Acode или Files)
# Перейди в папку
cd ~/aria-v6

# Установить зависимости
npm install
```

> ⚠️ Если ошибка с `node_modules` — удали и переустанови:
> ```bash
> rm -rf node_modules package-lock.json
> npm install
> ```

---

## Шаг 4 — Логин в Expo

```bash
eas login
# Введи email и пароль от expo.dev
```

---

## Шаг 5 — Инициализация EAS (только первый раз)

```bash
eas build:configure
# Выбери: Android
# На вопрос "Generate new keystore?" — выбери Yes
```

---

## Шаг 6 — Сборка APK ☁️

```bash
eas build --platform android --profile preview
```

Сборка происходит **в облаке** на серверах Expo — Termux только отправляет код.
Займёт 5–15 минут. В конце в терминале появится ссылка на скачивание APK.

---

## Шаг 7 — Скачать и установить APK

Ссылку из терминала открой в браузере телефона → скачай APK → установи
(Настройки → Безопасность → Разрешить установку из неизвестных источников)

---

## Частые ошибки

| Ошибка | Решение |
|--------|---------|
| `expo-av not found` | Удалена из зависимостей, проблем быть не должно |
| `icon.png not found` | Файл теперь есть в `assets/icon.png` |
| `buildType: apk` missing | Исправлено в `eas.json` |
| `401 Unauthorized` при запуске | Неверный API ключ Anthropic |
| Node < 18 | `pkg install nodejs-lts` |
| `ENOMEM` (нехватка памяти) | Закрой другие приложения, сборка идёт в облаке — это не критично |

---

## Заметки

- Приложение требует API ключ Anthropic: https://console.anthropic.com/keys
- Ключ начинается с `sk-ant-`
- Ключ хранится локально на устройстве в AsyncStorage
- Бесплатный тариф EAS даёт 30 сборок в месяц
